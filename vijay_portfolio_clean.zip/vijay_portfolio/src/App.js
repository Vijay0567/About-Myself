
import React from "react";
import { FaGithub, FaLinkedin, FaEnvelope, FaPhone } from "react-icons/fa";

export default function Portfolio() {
  return (
    <div className="bg-gray-900 text-white min-h-screen font-sans">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold">Vijay Gampala</h1>
        <p className="text-lg mt-2">B.Tech CSE Student | Web Developer | Problem Solver</p>
        <div className="flex justify-center gap-4 mt-4">
          <a href="mailto:vijaygampala0@gmail.com"><FaEnvelope size={24} /></a>
          <a href="tel:+919989854630"><FaPhone size={24} /></a>
          <a href="https://github.com/vijay0567" target="_blank"><FaGithub size={24} /></a>
          <a href="https://www.linkedin.com/in/vijaygampala" target="_blank"><FaLinkedin size={24} /></a>
        </div>
      </header>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold border-b border-gray-700 pb-2">About Me</h2>
        <p className="mt-4">I'm a passionate Computer Science Engineering student from Lovely Professional University, with hands-on experience in web technologies and hardware integration. I love building projects that solve real-world problems and I'm always keen to learn and grow.</p>
      </section>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold border-b border-gray-700 pb-2">Skills</h2>
        <ul className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
          <li>Java</li><li>C++</li><li>Python</li><li>C</li>
          <li>HTML5</li><li>CSS</li><li>JavaScript</li><li>React.js</li>
          <li>MySQL</li><li>Oracle 8i</li><li>Git</li><li>Linux</li>
        </ul>
      </section>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold border-b border-gray-700 pb-2">Projects</h2>
        <div className="mt-4">
          <div className="mb-6">
            <h3 className="text-xl font-bold">Real-Time Air Quality Monitoring System</h3>
            <p>Arduino-based system using MQ135 & DHT11 sensors with LCD for live data. Focused on sensor calibration, hardware integration, and environmental data visualization.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold">Grocery Website</h3>
            <p>Developed using HTML, CSS, JavaScript, and React.js. Features secure login, exercise videos, goal tracking, and a responsive mobile-friendly UI/UX.</p>
          </div>
        </div>
      </section>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold border-b border-gray-700 pb-2">Certifications</h2>
        <ul className="mt-4 list-disc list-inside">
          <li>Coursera: Lead Generation Chatbot using Chatfuel (Oct 2023)</li>
          <li>FreeCodeCamp: Responsive Web Design Certification (Oct 2018)</li>
          <li>Hackathon: Code-A-Haunt @ LPU - 24hr coding challenge</li>
        </ul>
      </section>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold border-b border-gray-700 pb-2">Education</h2>
        <ul className="mt-4 list-disc list-inside">
          <li>Lovely Professional University – B.Tech CSE (2023–2027), CGPA: 7.0</li>
          <li>Sri Gowthami College – Class 12 (2021–2023), 96%</li>
          <li>ZP High School – Class 10 (2020–2021), 96%</li>
        </ul>
      </section>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold border-b border-gray-700 pb-2">Extra-Curricular</h2>
        <ul className="mt-4 list-disc list-inside">
          <li>Active in debate & quiz competitions</li>
          <li>Served as sports captain and managed school events</li>
        </ul>
      </section>

      <footer className="text-center text-sm py-10 border-t border-gray-700">
        © 2025 Vijay Gampala. All rights reserved.
      </footer>
    </div>
  );
}
